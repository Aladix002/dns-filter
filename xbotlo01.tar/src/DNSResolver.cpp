#include "DNSResolver.hpp"
#include <fstream>
#include <iostream>
#include <algorithm>
#include <cctype>
#include <cstring>
#include <vector>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip6.h>
#include <netdb.h>
#include <unistd.h>
#include <csignal>
#include <fcntl.h>
#include <errno.h>

#define DNS_PORT 53

// Static member initialization
DNSResolver* DNSResolver::instance_ = nullptr;

// Konstruktor - nacitanie filtra a inicializacia
DNSResolver::DNSResolver(const std::string& resolver, int port, const std::string& filterFile, bool verbose, bool stats)
    : clientSocket4_(-1), clientSocket6_(-1), resolverSocket4_(-1), resolverSocket6_(-1), resolverAddress_(resolver), port_(port), verbose_(verbose), statsEnabled_(stats) {
    
    // Nastavenie instancie pre signal handling
    instance_ = this;
    
    if (!loadFilterFile(filterFile)) {
        throw std::runtime_error("Failed to load filter file: " + filterFile);
    }
}

// Destruktor, zatvaraju sa sockety
DNSResolver::~DNSResolver() {
    if (clientSocket4_ >= 0) {
        close(clientSocket4_);
    }
    if (clientSocket6_ >= 0) {
        close(clientSocket6_);
    }
    if (resolverSocket4_ >= 0) {
        close(resolverSocket4_);
    }
    if (resolverSocket6_ >= 0) {
        close(resolverSocket6_);
    }
    
    // Vypisuje statistiky na konci
    if (statsEnabled_) {
        printStatistics();
    }
    
    // Resetuje singleton instance
    instance_ = nullptr;
}

// Nacitava subor s blokovanymi domenami
bool DNSResolver::loadFilterFile(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Cannot open filter file: " << filename << std::endl;
        return false;
    }
    
    // Ukoncenia riadkov pre rozne OS: https://en.wikipedia.org/wiki/Newline#Representation
    std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    file.close();
    
    // Rozdeluje na riadky pre vsetky mozne ukoncenia riadkov
    std::vector<std::string> lines;
    std::string line;
    for (char c : content) {
        if (c == '\n' || c == '\r') {
            if (!line.empty()) {
                lines.push_back(line);
                line.clear();
            }
        } else {
            line += c;
        }
    }
    if (!line.empty()) {
        lines.push_back(line);
    }
    
    for (const std::string& currentLine : lines) {
        // Preskakuje prazdne riadky a komentare
        if (currentLine.empty() || currentLine[0] == '#') {
            continue;
        }
        
        // Normalizacia a pridanie do blokovanych domen
        std::string normalized = currentLine;
        // Konverzia na male pismena
        std::transform(normalized.begin(), normalized.end(), normalized.begin(), ::tolower);
        
        // Odstranuje koncove bodky, medzery a konce riadkov
        while (!normalized.empty() && (normalized.back() == '.' || normalized.back() == ' ' || 
               normalized.back() == '\r' || normalized.back() == '\n')) {
            normalized.pop_back();
        }
        
        if (!normalized.empty()) {
            blockedDomains_.push_back(normalized);
        }
    }
    
    return true;
}


// Vytvara client socket pre konkretnu IP verziu
// Referencia: https://man7.org/linux/man-pages/man2/socket.2.html
int DNSResolver::createClientSocket(int port, int family) {
    int sockfd = socket(family, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        return -1;
    }
    
    // Nastavuje SO_REUSEADDR
    int opt = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        close(sockfd);
        return -1;
    }
    
    // Nastavuje non-blocking mode pre paralelne spracovanie
    int flags = fcntl(sockfd, F_GETFL, 0);
    if (flags >= 0) {
        fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);
    }
    
    if (family == AF_INET6) {
        int v6only = 1;
        if (setsockopt(sockfd, IPPROTO_IPV6, IPV6_V6ONLY, &v6only, sizeof(v6only)) < 0) {
            close(sockfd);
            return -1;
        }
        
        // Bind na IPv6 adresu
        struct sockaddr_in6 addr6;
        memset(&addr6, 0, sizeof(addr6));
        addr6.sin6_family = AF_INET6;
        addr6.sin6_addr = in6addr_any;
        addr6.sin6_port = htons(port);
        
        if (bind(sockfd, (struct sockaddr*)&addr6, sizeof(addr6)) == 0) {
            return sockfd;
        } else {
            close(sockfd);
            return -1;
        }
    } else if (family == AF_INET) {
        // Bind na IPv4 adresu
        struct sockaddr_in addr4;
        memset(&addr4, 0, sizeof(addr4));
        addr4.sin_family = AF_INET;
        addr4.sin_addr.s_addr = INADDR_ANY;
        addr4.sin_port = htons(port);
        
        if (bind(sockfd, (struct sockaddr*)&addr4, sizeof(addr4)) == 0) {
            return sockfd;
        } else {
            close(sockfd);
            return -1;
        }
    }
    
    close(sockfd);
    return -1;
}

// Vytvorenie resolver socketu - pripojenie k DNS serveru prebrane z: https://man7.org/linux/man-pages/man2/socket.2.html
int DNSResolver::createResolverSocket(const std::string& resolver, int port, int family) {
    // Skusenie IPv6 adresy
    struct in6_addr addr6;
    if (inet_pton(AF_INET6, resolver.c_str(), &addr6) == 1) {
        if (family != AF_INET6) {
            return -1; // Nie je IPv6 adresa
        }
        int sockfd = socket(AF_INET6, SOCK_DGRAM, 0);
        if (sockfd < 0) {
            std::cerr << "Failed to create IPv6 socket for resolver: " << resolver << std::endl;
            return -1;
        }
        
        struct sockaddr_in6 serverAddr;
        memset(&serverAddr, 0, sizeof(serverAddr));
        serverAddr.sin6_family = AF_INET6;
        serverAddr.sin6_addr = addr6;
        serverAddr.sin6_port = htons(port);
        
        if (connect(sockfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == 0) {
            return sockfd;
        }
        
        close(sockfd);
        std::cerr << "Failed to connect to IPv6 DNS resolver: " << resolver << std::endl;
        return -1;
    }
    
    // Skusenie IPv4 adresy
    struct in_addr addr4;
    if (inet_pton(AF_INET, resolver.c_str(), &addr4) == 1) {
        if (family != AF_INET) {
            return -1; // Nie je IPv4 adresa
        }
        int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
        if (sockfd < 0) {
            std::cerr << "Failed to create IPv4 socket for resolver: " << resolver << std::endl;
            return -1;
        }
        
        struct sockaddr_in serverAddr;
        memset(&serverAddr, 0, sizeof(serverAddr));
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_addr = addr4;
        serverAddr.sin_port = htons(port);
        
        if (connect(sockfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == 0) {
            return sockfd;
        }
        
        close(sockfd);
        std::cerr << "Failed to connect to IPv4 DNS resolver: " << resolver << std::endl;
        return -1;
    }
    
    // Nie je to priama IP adresa, skusi sa DNS lookup pre konkretnu IP verziu
    struct addrinfo hints, *result;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = family;
    hints.ai_socktype = SOCK_DGRAM;
    
    if (getaddrinfo(resolver.c_str(), std::to_string(port).c_str(), &hints, &result) != 0) {
        return -1; 
    }
    
    // Skusi vsetky adresy danej IP verzie
    int sockfd = -1;
    for (struct addrinfo* rp = result; rp != nullptr; rp = rp->ai_next) {
        if (rp->ai_family != family) continue;
        
        sockfd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
        if (sockfd < 0) continue;
        
        if (connect(sockfd, rp->ai_addr, rp->ai_addrlen) == 0) {
            break;
        }
        
        close(sockfd);
        sockfd = -1;
    }
    
    freeaddrinfo(result);
    
    return sockfd;
}

// Inicializacia socketov - vytvorenie client a resolver socketov
bool DNSResolver::initialize() {
    // Vytvorenie IPv4 socketu
    clientSocket4_ = createClientSocket(port_, AF_INET);
    if (clientSocket4_ < 0) {
        if (verbose_) {
            std::cerr << "Varovanie: Nepodarilo sa vytvorit IPv4 socket" << std::endl;
        }
    }
    
    // Vytvara IPv6 socket
    clientSocket6_ = createClientSocket(port_, AF_INET6);
    if (clientSocket6_ < 0) {
        if (verbose_) {
            std::cerr << "Varovanie: Nepodarilo sa vytvorit IPv6 socket" << std::endl;
        }
    }
    
    if (clientSocket4_ < 0 && clientSocket6_ < 0) {
        std::cerr << "Chyba: Nepodarilo sa vytvorit ani IPv4 ani IPv6 socket" << std::endl;
        return false;
    }
    
    // Vytvorenie IPv4 resolver socketu
    resolverSocket4_ = createResolverSocket(resolverAddress_, DNS_PORT, AF_INET);
    if (resolverSocket4_ < 0 && verbose_) {
        std::cerr << "Varovanie: Nepodarilo sa vytvorit IPv4 resolver socket" << std::endl;
    }
    
    // Vytvorenie IPv6 resolver socketu
    resolverSocket6_ = createResolverSocket(resolverAddress_, DNS_PORT, AF_INET6);
    if (resolverSocket6_ < 0 && verbose_) {
        std::cerr << "Varovanie: Nepodarilo sa vytvorit IPv6 resolver socket" << std::endl;
    }
    
    if (resolverSocket4_ < 0 && resolverSocket6_ < 0) {
        std::cerr << "Chyba: Nepodarilo sa vytvorit ani IPv4 ani IPv6 resolver socket" << std::endl;
        if (clientSocket4_ >= 0) close(clientSocket4_);
        if (clientSocket6_ >= 0) close(clientSocket6_);
        return false;
    }
    
    return true;
}


// Spracovanie prichadzajuceho DNS dotazu podla: https://tools.ietf.org/html/rfc1035
void DNSResolver::handleQuery(const char* buffer, int len, const struct sockaddr_storage& clientAddr, int clientSocket) {
    // Pouzitie DNSProtocol pre spracovanie dotazu
    DNSResponseCode responseCode = DNSProtocol::processQuery(buffer, len, clientAddr, blockedDomains_, verbose_, statsEnabled_ ? &stats_ : nullptr);
    
    if (responseCode != DNSResponseCode::NOERROR) {
        DNSProtocol::sendErrorResponse(clientSocket, buffer, len, clientAddr, responseCode);
        return;
    }
    
    // Vyberie vhodny resolver socket podla IP verzie klienta
    int resolverSocket = -1;
    if (clientAddr.ss_family == AF_INET6 && resolverSocket6_ >= 0) {
        resolverSocket = resolverSocket6_;
    } else if (clientAddr.ss_family == AF_INET && resolverSocket4_ >= 0) {
        resolverSocket = resolverSocket4_;
    } else {
        // Fallback: pouzije prvy dostupny resolver socket
        if (resolverSocket4_ >= 0) {
            resolverSocket = resolverSocket4_;
        } else if (resolverSocket6_ >= 0) {
            resolverSocket = resolverSocket6_;
        }
    }
    
    // Kontrola ci je resolver dostupny
    if (resolverSocket < 0) {
        DNSProtocol::sendErrorResponse(clientSocket, buffer, len, clientAddr, DNSResponseCode::SERVFAIL);
        return;
    }
    
    // Ziskanie DNS ID z hlavicky
    dns_header* header = (dns_header*)buffer;
    uint16_t dnsId = ntohs(header->id);
    
    // Vytvorenie unikatneho kľúča (DNS ID + adresa klienta)
    QueryKey queryKey;
    queryKey.dnsId = dnsId;
    memcpy(&queryKey.clientAddr, &clientAddr, sizeof(clientAddr));
    
    // Ulozenie informacii o klientovi pre neskorsie odoslanie odpovede
    ClientInfo clientInfo;
    memcpy(&clientInfo.addr, &clientAddr, sizeof(clientAddr));
    if (clientAddr.ss_family == AF_INET) {
        clientInfo.addrLen = sizeof(struct sockaddr_in);
    } else if (clientAddr.ss_family == AF_INET6) {
        clientInfo.addrLen = sizeof(struct sockaddr_in6);
    } else {
        clientInfo.addrLen = sizeof(clientAddr);
    }
    clientInfo.socket = clientSocket;
    clientInfo.resolverSocket = resolverSocket;  // Ulozenie resolver socketu
    
    // Ulozenie do mapy (pouziva unikatny kľúč, takze nedochadza k koliziam)
    pendingQueries_[queryKey] = clientInfo;
    
    // Presmerovava dotaz na resolver
    if (send(resolverSocket, buffer, len, 0) < 0) {
        std::cerr << "Chyba pri odosielani dotazu na resolver" << std::endl;
        pendingQueries_.erase(queryKey);
        return;
    }
    
    // Aktualizuje statistiky pre preposlane dotazy 
    if (statsEnabled_) {
        stats_.forwardedQueries++;
    }
    
    // Odpoved prichadza asynchronne cez handleResolverResponse()
}

// Spracovanie odpovede od resolvera
void DNSResolver::handleResolverResponse(int resolverSocket) {
    char responseBuffer[MAX_DNS_SIZE];
    int received = recv(resolverSocket, responseBuffer, MAX_DNS_SIZE, 0);
    
    if (received < 0) {
        std::cerr << "Chyba pri prijimani odpovede od resolvera" << std::endl;
        return;
    }
    
    if (received < (int)sizeof(dns_header)) {
        return;
    }
    
    // Ziskanie DNS ID z odpovede
    dns_header* header = (dns_header*)responseBuffer;
    uint16_t dnsId = ntohs(header->id);
    
    // Musime najst odpovedajuci klient podla DNS ID a resolver socketu
    // Prejdeme vsetky pending queries a najdeme tie s rovnakym DNS ID
    // a rovnakym resolver socketom (to zabezpecuje, ze odpoved ide spravnemu klientovi)
    auto it = pendingQueries_.begin();
    while (it != pendingQueries_.end()) {
        if (it->first.dnsId == dnsId && it->second.resolverSocket == resolverSocket) {
            // Nasli sme zhodu - odosleme odpoved
            ClientInfo& clientInfo = it->second;
            
            // Odoslanie odpovede klientovi
            if (sendto(clientInfo.socket, responseBuffer, received, 0,
                       (const struct sockaddr*)&clientInfo.addr, clientInfo.addrLen) < 0) {
                std::cerr << "Chyba pri odosielani odpovede klientovi" << std::endl;
            }
            
            // Odstranenie z mapy
            it = pendingQueries_.erase(it);
            return; // Nasli sme a spracovali sme odpoved
        } else {
            ++it;
        }
    }
    
    // Ak sme nenasli zhodu, odpoved sa ignoruje
}

// Vypisuje statistiky
void DNSResolver::printStatistics() const {
    if (!statsEnabled_) {
        return;
    }
    
    std::cout << "total queries: " << stats_.totalQueries << std::endl;
    std::cout << "blocked: " << stats_.blockedQueries << std::endl;
    std::cout << "forwarded: " << stats_.forwardedQueries << std::endl;
    std::cout << "notimp: " << stats_.otherTypeQueries << std::endl;
    std::cout << "blocked - exact matches: " << stats_.exactMatches << std::endl;
    std::cout << "blocked - subdomain matches: " << stats_.subdomainMatches << std::endl;
}

// Signal handler pre SIGINT (Ctrl+C)
void DNSResolver::signalHandler(int signal) {
    if (signal == SIGINT && instance_ != nullptr) {
        if (instance_->statsEnabled_) {
            std::cout << std::endl;
            instance_->printStatistics();
        }
        exit(0);
    }
}


// Hlavny server loop - cakanie na dotazy a ich spracovanie 
void DNSResolver::run() {
    if (!initialize()) {
        throw std::runtime_error("Failed to initialize DNS filter");
    }
    
    // Nastavenie signal handler pre SIGINT
    signal(SIGINT, signalHandler);
    
    if (verbose_) {
        std::cout << "dns filter started on port: " << port_ << std::endl;
        std::cout << "resolver: " << resolverAddress_ << std::endl;
    }
    
    struct sockaddr_storage clientAddr;
    socklen_t addrLen = sizeof(clientAddr);
    
    // Hlavny cyklus
    while (true) {
        fd_set readfds;
        FD_ZERO(&readfds);
        
        int maxfd = -1;
        if (clientSocket4_ >= 0) {
            FD_SET(clientSocket4_, &readfds);
            maxfd = std::max(maxfd, clientSocket4_);
        }
        if (clientSocket6_ >= 0) {
            FD_SET(clientSocket6_, &readfds);
            maxfd = std::max(maxfd, clientSocket6_);
        }
        if (resolverSocket4_ >= 0) {
            FD_SET(resolverSocket4_, &readfds);
            maxfd = std::max(maxfd, resolverSocket4_);
        }
        if (resolverSocket6_ >= 0) {
            FD_SET(resolverSocket6_, &readfds);
            maxfd = std::max(maxfd, resolverSocket6_);
        }
        
        if (maxfd < 0) {
            std::cerr << "Ziadny socket nie je dostupny" << std::endl;
            break;
        }
        
        int result = select(maxfd + 1, &readfds, nullptr, nullptr, nullptr);
        if (result < 0) {
            std::cerr << "Chyba v select" << std::endl;
            continue;
        }
        
        // Spracovanie vsetkych pripravenych socketov v jednom cykle
        // Toto umoznuje paralelne spracovanie dotazov a odpovedi
        
        // Spracovanie IPv4 socket - spracujeme vsetky dostupne pakety
        if (clientSocket4_ >= 0 && FD_ISSET(clientSocket4_, &readfds)) {
            while (true) {
                char buffer[MAX_DNS_SIZE];
                addrLen = sizeof(clientAddr);
                int n = recvfrom(clientSocket4_, buffer, MAX_DNS_SIZE, 0,
                                (struct sockaddr*)&clientAddr, &addrLen);
                
                if (n > 0) {
                    handleQuery(buffer, n, clientAddr, clientSocket4_);
                } else if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
                    // Ziadne dalsie data
                    break;
                } else {
                    break;
                }
            }
        }
        
        // Spracovanie IPv6 socketu - spracujeme vsetky dostupne pakety
        if (clientSocket6_ >= 0 && FD_ISSET(clientSocket6_, &readfds)) {
            while (true) {
                char buffer[MAX_DNS_SIZE];
                addrLen = sizeof(clientAddr);
                int n = recvfrom(clientSocket6_, buffer, MAX_DNS_SIZE, 0,
                                (struct sockaddr*)&clientAddr, &addrLen);
                
                if (n > 0) {
                    handleQuery(buffer, n, clientAddr, clientSocket6_);
                } else if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
                    // Ziadne dalsie data
                    break;
                } else {
                    break;
                }
            }
        }
        
        // Spracovanie odpovede od resolvera (IPv4) - spracujeme vsetky dostupne odpovede
        if (resolverSocket4_ >= 0 && FD_ISSET(resolverSocket4_, &readfds)) {
            while (true) {
                handleResolverResponse(resolverSocket4_);
                
                // Skontrolujeme, ci su este nejake data
                fd_set checkfds;
                FD_ZERO(&checkfds);
                FD_SET(resolverSocket4_, &checkfds);
                struct timeval timeout;
                timeout.tv_sec = 0;
                timeout.tv_usec = 0;
                if (select(resolverSocket4_ + 1, &checkfds, nullptr, nullptr, &timeout) <= 0) {
                    break;
                }
            }
        }
        
        // Spracovanie odpovede od resolvera (IPv6) - spracujeme vsetky dostupne odpovede
        if (resolverSocket6_ >= 0 && FD_ISSET(resolverSocket6_, &readfds)) {
            while (true) {
                handleResolverResponse(resolverSocket6_);
                
                // Skontrolujeme, ci su este nejake data
                fd_set checkfds;
                FD_ZERO(&checkfds);
                FD_SET(resolverSocket6_, &checkfds);
                struct timeval timeout;
                timeout.tv_sec = 0;
                timeout.tv_usec = 0;
                if (select(resolverSocket6_ + 1, &checkfds, nullptr, nullptr, &timeout) <= 0) {
                    break;
                }
            }
        }
    }
}
